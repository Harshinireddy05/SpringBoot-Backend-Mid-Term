package org.example.cartserviceproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartServiceProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(CartServiceProjectApplication.class, args);
    }

}
