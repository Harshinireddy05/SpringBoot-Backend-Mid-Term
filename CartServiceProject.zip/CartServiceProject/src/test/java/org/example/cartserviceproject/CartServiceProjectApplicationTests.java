package org.example.cartserviceproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartServiceProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
